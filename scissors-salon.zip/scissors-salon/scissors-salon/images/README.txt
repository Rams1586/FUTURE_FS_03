Put real salon photos here, then follow the "Replacing the placeholder
content" section of the main README.md to wire them into the page
(hero panel, about section, gallery tiles).

Suggested files:
- studio.jpg        (interior shot, used in the About section)
- gallery-1.jpg ... gallery-6.jpg   (used in the Gallery grid)
